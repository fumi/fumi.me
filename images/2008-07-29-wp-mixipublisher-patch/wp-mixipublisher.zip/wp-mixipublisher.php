<?php
/*
Plugin Name: Wp-MixiPublisher
Plugin URI: http://exth.net/~togabito/
Description: Wordpressの投稿を、Mixiの日記へも投稿するプラグイン。mixi 2007/12/18 変更対応版
Author: original yu-ji(http://factage.com/yu-ji/) / modified tgbt
Author URI: http://exth.net/~togabito/
Version: 1.0.0 RC2 +c
*/
/*  Copyright 2006 yu-ji (http://factage.com/yu-ji/)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
define('WP_MIXIPUBLISHER_VERSION', '1.0.0 RC2 +c');
define('WP_MIXIPUBLISHER_DEBUGMODE', 0);
define('WP_MIXIPUBLISHER_DEBUGPATH', '/path/to/debug');

if(mixipublisher_isEnableSelfExecute()) {
    require('../../../wp-blog-header.php');
}
require_once('wp-babel-wpmp.php');

class WpMixiPublisherController extends WpBabelController_01a_wpmp {
    var $_publishedId = array();
    
    /**
     * WpMixiPublisherController のインスタンスを取得する。（シングルトン）
     */
    function &getInstance(){
        static $instance;
        if(!isset($instance)){
            $instance = new WpMixiPublisherController();
        }
        return $instance;
    }
    
    /**
     * WpMixiPublisherController のコンストラクタ。
     */
    function WpMixiPublisherController() {
        
        $plugin_name = 'wp-mixipublisher';
        $plugin_panel_name = 'Wp-MixiPublisher';
        $access_level = 8;

/*        
        $this->initialize(
            $plugin_name,
            $plugin_panel_name,
            $access_level);
*/        
        $commonVO = new WPBabelSettingVO_01a_wpmp();
        $commonVO->setParam('name', $plugin_name);
        $commonVO->setParam('version', get_bloginfo('version'));
        
        $this->wpbview = & new WpMixiPublisherView($commonVO);
        $this->wpbmodel = & new WpMixiPublisherModelFacard();

        $this->initialize(
            $plugin_name,
            $plugin_panel_name,
            $access_level);
    }
    
    /**
     * WpMixiPublisherController の初期化。
     * @params string $plugin_name
     * @params string $plugin_panel_name
     * @params integer $access_level
     */
    function initialize(
        $plugin_name = 'wp-babel',
        $plugin_panel_name = 'wp-babel',
        $access_level = 8) {
        global $wpdb;
        
        parent::initialize($plugin_name, $plugin_panel_name, $access_level);
        
        $this->upgrade();
        
        $column_name = 'mixi_diary_id';
        foreach ($wpdb->get_col("DESC $wpdb->posts", 0) as $column ) {
            if ($column == $column_name) {
                return;
            }
        }
        // didn't find it... create it
        $wpdb->query("ALTER TABLE $wpdb->posts ADD COLUMN mixi_diary_id bigint unsigned");
    }
    
    function upgrade() {
        $settingVO =& $this->getWpSetting();
        // 1.0.0rc1からのアップグレード
        if($settingVO->getParam('quotes') === null) {
            $settingVO->setParam('quotes', 'blockquote');
            $this->updateWpSetting($settingVO);
        }
    }
    
    function publishToMixi($postId) {
        global $wpdb, $user_ID;
        
        if(!current_user_can('edit_post', $postId)) {
            return $postId;
        }
        
        $settingVO = $this->getWpSetting();
        
        $mixi = new MixiGateway($settingVO->getParam('email'), $settingVO->getParam('password'));
        if(!$mixi->login() || !$mixi->isEnabledMixiDiary()) {
            return $postId;
        }
        $post = get_post($postId);

        $title = $post->post_title;
        $title = mb_convert_encoding($title, 'eucjp-win', $settingVO->getParam('blog_charset'));
        
        $content = '';
        if($settingVO->getParam('type') == 3) {
            $content = apply_filters('the_content', $post->post_content);
        }else if($settingVO->getParam('type') == 2) {
            $content = explode('<!--more-->', $post->post_content, 2);
            $content = apply_filters('the_content', $content[0]);
        }

        $quote_tags = preg_split('/[\s,]+/', $settingVO->getParam('quotes'), 0, PREG_SPLIT_NO_EMPTY);
        
        $content = strip_tags($content, '<a>'.($quote_tags ? '<'.join('><', $quote_tags).'>' : ''));

        /*
        $content = preg_replace_callback('/<a\s+href="([^"]+)"[^<>]*>((?:(?!<\/a>).)+)<\/a>/', create_function(
            '$matches',
            '$matches[1] = strpos($matches[1], "/") === 0 ? get_settings("siteurl").$matches[1] : $matches[1];'.
            'return $matches[1] == trim($matches[2]) ? $matches[2] : $matches[2]."(".$matches[1].")";'
        ), $content);
        */
        $content = preg_replace_callback(
        '/<a[^<>]+href=["|\']([^"|~\']*)["|\'][^&lt:>]*>((?:(?!<\/a>).)+)<\/a>/', create_function(
        '$matches',
        '$matches[1] = strpos($matches[1], "/") === 0 ? get_settings("siteurl").$matches[1] : $matches[1];'.
        'if(empty($matches[1])){
        return $matches[2];
        }else{
        return $matches[1] == trim($matches[2]) ? $matches[2] : $matches[2]."(".$matches[1].")"; }')
        , $content);
        
        foreach($quote_tags as $tag) {
            $content = preg_replace_callback('/<'.$tag.'[^<>]*>\s*((?:(?!<\/'.$tag.'>).)+)<\/'.$tag.'>/s', create_function(
                '$matches',
                'return preg_replace("/(&gt;\s*)+$/", "", preg_replace("/^/m", "&gt;", $matches[1]));'
            ), $content);
        }
        
        $footer = sprintf($settingVO->getParam('footer'), get_permalink($postId));
        $footer = mb_convert_encoding($footer, 'eucjp-win', $settingVO->getParam('blog_charset'));
        $content = mb_convert_encoding($content, 'eucjp-win', $settingVO->getParam('blog_charset'));

	/*
	 headerにするかfooterにするか。設定からいじれるようにすればいいんだけど、放っといて良いよね
	*/
	/*
	 フッターを先に出力するtgbtカスタム。
	 $content = ltrim($footer."\n\n".rtrim($content));
	*/
        /*
	 フッターを前に出力するデフォルトバージョン。
	 $content = ltrim(rtrim($content)."\n\n".$footer);
	*/
	$content = ltrim(rtrim($content)."\n\n".$footer);
	
        if($post->mixi_diary_id && $mixi->existsDiary($post->mixi_diary_id)) {
            $mixi->modifyDiary($post->mixi_diary_id, $title, $content);
        }else{
            $mixi_diary_id = $mixi->addDiary($title, $content);
            if($mixi_diary_id) {
                $wpdb->query("UPDATE $wpdb->posts SET mixi_diary_id = $mixi_diary_id WHERE ID = $postId");
            }
        }
    }
    
    function getPublishForm() {
        global $post, $tableposts;
        
        $settingVO =& $this->getWpSetting();
        $form = array();
        if($settingVO->getParam('user_id')){
            $default = $settingVO->getParam('default');
            $diaryId = null;
            $postObj = null;
            if($post) {
                if(is_object($post) && $post->ID) {
                    $postObj = $post;
                }else if(!is_object($post) && $post) {
                    $postObj = get_post($post);
                }
                $diaryId = $postObj->mixi_diary_id;
            }
            $form[] = '<fieldset id="mixipublisherdiv" class="dbx-box">';
            $form[] = '<h3 class="dbx-handle">MixiPublisher</h3> ';
            $form[] = '<div class="dbx-content">';
            $checked = '';
            if(($postObj && $diaryId && $default) || ((!$postObj || $postObj->post_status != 'publish') && $default)) {
                $checked = 'checked="checked"';
            }
            $form[] = '<label for="publish_mixi" class="selectit"><input type="checkbox" name="publish_mixi" id="publish_mixi" value="1" '.$checked.'/> '.($diaryId ? __('Mixiのこの記事を更新する') : __('Mixiへこの記事を投稿する')).'</label>';
            if($diaryId) {
                $form[]= '<div style="text-align: right;"><small><a href="http://mixi.jp/view_diary.pl?id='.$diaryId.'&owner_id='.$settingVO->getParam('user_id').'" target="_blank">&raquo; Mixiの日記を確認</a></small></div>';
            }
            $form[] = '</div>';
            $form[] = '</fieldset>';
        }
        echo "\n".join("\n", $form)."\n";
    }
    
    function actionAdmin($settingVO, $requestVO) {
      // 設定画面を開いたときに呼ばれる部分
      // ただしWpMixiPublisherController生成時のコンストラクタがあるので注意
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "actionAdmin@actionAdmin\n");
	fclose($ftmp);
      }
      $this->wpbview->actionAdmin($settingVO);
    }
    
    function actionAdminSubmit($settingVO, $requestVO) {
        $result = $this->wpbmodel->actionAdminSubmit(
            $settingVO, $requestVO);
        $this->updateWpSetting($result);
        $this->wpbview->actionAdminSubmit($result);
    }
    
    function executePublishToMixi($postId, $isModify=false) {
        if(in_array($postId, $this->_publishedId)) {
            return false;
        }
        $settingVO = $this->getWpSetting();
        if(!$settingVO->getParam('user_id')) {
            return false;
        }
        
        $post = get_post($postId);
        
        // 公開しない場合は終了
        if($post->post_status != 'publish') {
            return false;
        }
        
        // 1.0.0 RC2: XML-RPCリクエストの場合ディフォルト設定を優先する
        if(defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            // ディフォルト設定が有効でなければ終了
            if($settingVO->getParam('default') != 1) {
                return false;
            }
            // すでにある投稿で、Mixiに投稿していなければ終了
            if(!$postObj->mixi_diary_id && $isModify) {
                return false;
            }
        }else{
            if($_POST['publish_mixi'] != 1) {
                return false;
            }
        }
        
        // 1.0.0 RC2: リクエストに利用するクッキーを既存のものからではなく、新しく作成する
        $user = wp_get_current_user();
        $cookies = USER_COOKIE.'='.urlencode($user->user_login).'; ';
        $cookies.= PASS_COOKIE.'='.md5($user->user_pass);
        
        $relative_path = preg_replace('/^'.preg_quote(ABSPATH, '/').'/', '/', __FILE__);
        
        $ping_url = get_settings('siteurl') . $relative_path;
        $parts = parse_url($ping_url);
        $argyle = @ fsockopen(
                $parts['host'],
                $_SERVER['SERVER_PORT'],
                $errno,
                $errstr,
                0.01);

        if ($argyle) {
            fputs($argyle, "GET {$parts['path']}?" .
                "post_id=" . $postId .
                " HTTP/1.0\r\nHost: {$parts['host']}\r\nCookie: {$cookies}\r\n\r\n");
        }
        $this->_publishedId[] = $postId;
        return $postId;
    }
    
    function saveHandler($postId) {
	if($postId = $this->executePublishToMixi($postId, true))
		$this->publishToMixi($postId);
    }
    
    function publishHandler($postId) {
        if($postId = $this->executePublishToMixi($postId))
		$this->publishToMixi($postId);
    }
}

class WpMixiPublisherModelFacard extends WpBabelModelFacerd_01a_wpmp {
  function actionAdminSubmit($settingVO, $requestVO) {
    if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
      $ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
      fwrite($ftmp, "actionAdminSubmit\n");
      /*
       foreach($param as $tmp){
       fwrite($ftmp, $tmp);
       fwrite($ftmp, "\n");
       }
      */
      fclose($ftmp);
    }
    
    $result = new WPBabelSettingVO_01a_wpmp();
    
    $email     = $requestVO->getParam('email');
    $password  = $requestVO->getParam('password');
    $default   = $requestVO->getParam('default');
    $type      = $requestVO->getParam('type');
    $footer    = $requestVO->getParam('footer');
    $quotes    = $requestVO->getParam('quotes');

    if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
      $ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
      fwrite($ftmp, "actionAdminSubmit\n");
      fwrite($ftmp, "email:".$email."\n");
      fwrite($ftmp, "password:".$password."\n");
      fwrite($ftmp, "default:".$default."\n");
      fwrite($ftmp, "type:".$type."\n");
      fwrite($ftmp, "footer:".$footer."\n");
      fwrite($ftmp, "quotes:".$quotes."\n");
      fclose($ftmp);
    }

    $result->setParam('email'   , $email);
    if(!$password) {
      $password = $settingVO->getParam('password');
    }
    $result->setParam('password', $password);
    $result->setParam('default' , $default);
    $result->setParam('type'    , $type);
    $result->setParam('footer'  , $footer);
    $result->setParam('quotes'  , $quotes);
    
    $result->setParam('user_id' , null);
    if($email && $password) {
      $mixi = new MixiGateway($email, $password);
      $tmpLoginID = $mixi->login();
      $tmpEnable = $mixi->isEnabledMixiDiary();
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "actionAdminSubmit / set user_id\n");
	fwrite($ftmp, "login: ".$tmpLoginID."\n");
	if($tmpEnable==true){
	  fwrite($ftmp, "isEnabledMixiDiary: OK\n");
	}else{
	  fwrite($ftmp, "isEnabledMixiDiary: NG\n");
	}
	fclose($ftmp);
      }
      
      if($tmpLoginID && $tmpEnable) {
	$result->setParam('user_id' , $mixi->getUserId());
      }else{
      }
    }
    
    return $result;
  }
  
    function setDefalutSetting() {
        $result = new WPBabelSettingVO_01a_wpmp();
        
        $result->setParam('user_id' , null);
        $result->setParam('email'   , '');
        $result->setParam('password', '');
        $result->setParam('default' , 0);
        $result->setParam('type'    , 2);
        $result->setParam('footer'  , __("この記事は外部のブログを使っています。\n記事を読まれる場合は、以下のURLをクリックしてください。\n\n%s"));
        $result->setParam('quotes'  , 'blockquote');
        
        return $result;
    }
}

class WpMixiPublisherView extends WpBabelView_01a_wpmp {
    function actionAdmin(&$mapVO) {
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "actionAdmin@WpMixiPublisherView\n");
	fclose($ftmp);
      }

        echo '<div class="wrap">' . "\n";
        echo '<form method="post">' . "\n";
        echo "<h2>" . __('Wp-MixiPublisherの設定') . "</h2>" . "\n";
        
        echo '<table class="optiontable">' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('MixiPublisherの有効状況'). '</th>';
        if($mapVO->getParam('user_id')) {
            echo '<td><strong>有効</strong></td>';
        }else{
            echo '<td><strong style="color: #F00;">無効</strong><br /><small>Mixiへログインできないか、Mixiの日記が外部のブログに設定されています。</small></td>';
        }
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('ログインメールアドレス'). '</th>';
        echo '<td><input name="email" type="text" id="email" value="'.$mapVO->getParam('email').'" size="50" class="code" /></td>';
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('ログインパスワード<small>（変更する際、入力してください）</small>'). '</th>';
        echo '<td><input name="password" type="password" id="password" value="" size="20" class="code" /></td>';
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('新規投稿時ディフォルトでMixiへ登録する'). '</th>';
        echo '<td><input name="default" type="checkbox" id="default" value="1" class="code" '.($mapVO->getParam('default') ? 'checked="checked" ': '').'/></td>';
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('Mixiへの登録内容'). '</th>';
        echo '<td>' . "\n";
        echo '<input name="type" type="radio" id="type_1" value="1" class="code" ' . ($mapVO->getParam('type') == '1' ? 'checked="checked"' : '') . '/> ' . __('無し') . "\n";
        echo '<input name="type" type="radio" id="type_2" value="2" class="code" ' . ($mapVO->getParam('type') == '2' ? 'checked="checked"' : '') . '/> ' . __('概要') . "\n";
        echo '<input name="type" type="radio" id="type_3" value="3" class="code" ' . ($mapVO->getParam('type') == '3' ? 'checked="checked"' : '') . '/> ' . __('全文') . "\n";
        echo '</td>' . "\n";
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('登録内容のフッター<small>（%s は記事へのURLに置換されます）</small>'). '</th>';
        echo '<td><textarea name="footer" style="width: 400px;height: 100px;">'.$mapVO->getParam('footer').'</textarea></td>';
        echo '</tr>' . "\n";
        
        echo '<tr>';
        echo '<th scope="row">' . __('引用とするタグ<small>（複数ある場合はカンマで区切りますす）</small>'). '</th>';
        echo '<td><input name="quotes" type="text" id="quotes" value="'.$mapVO->getParam('quotes').'" size="50" class="code" /></td>';
        echo '</tr>' . "\n";
        
        echo '</table>' . "\n";
        
        echo '<p class="submit"><input type="submit" name="submit" value="' .__('設定を更新する &raquo;') . '" />' . "\n";
        echo '<input type="hidden" name="action" value="submit" />';
        echo '</form>' . "\n";
        echo '</div>' . "\n";
    }
    
    function actionAdminSubmit(&$mapVO) {
        if($mapVO->getParam('user_id')){
            $this->putMessage(__('設定を更新しました'));
        }else{
            $this->putErrorMessage('<span style="color: #ff0000;">'.__('>Mixiへログインできないか、Mixiの日記が外部のブログに設定されています。').'</span>');
        }
        $this->actionAdmin($mapVO);
    }
}

class MixiGateway {
    var $base_url = 'http://mixi.jp/';
    var $email = '';
    var $password = '';
    var $snoopy = null;
    var $loggedin = false;
    var $mixi_diary_formval = array(
'submit',
'packed',
'post_key',
'news_id',
'campaign_id',
'id',
'diary_title',
'diary_body',
'news_title',
'news_url',
'movie_id',
'movie_url'
/*
        'id',
        'news_id',
        'diary_title',
        'diary_body',
        'photo1',
        'photo2',
        'photo3',
        'orig_size',
        'packed',
        'post_key',
*/
    );

    
    function MixiGateway($email, $password) {
        $this->email = $email;
        $this->password = $password;
        
        require_once(ABSPATH.WPINC.'/class-snoopy.php');
        $this->snoopy = new Snoopy();
        $this->snoopy->agent = 'Wp-MixiPublisher/'.WP_MIXIPUBLISHER_VERSION;
    }
    
    function login($url = 'home.pl') {
        $param = array('email' => $this->email,
            'password' => $this->password,
            'next_url' => '/' . $url,
            'sticky' => 'on'
        );
        
        $this->submit('login.pl', $param);
        $this->loggedin = empty($this->snoopy->cookies['BF_SESSION']) ? false : true;

        return $this->loggedin;
    }
    
    function submit($action, $param) {
        $action = (strpos($action, 'http://') !== false) ? $action : $this->base_url . $action;
        $result = $this->snoopy->submit($action, $param);

	if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	  $ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."submit2.html", "wb");
	  fwrite($ftmp, $result);
	  fclose($ftmp);
	}

        return $this->snoopy->results;
    }
    
    function addDiary($diary_title, $diary_body) {
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "addDiary開始\n");
	fclose($ftmp);
      }

      if(!$this->loggedin) {
	return false;
      }
      $latestDiaryId = $this->getLatestDiaryId();
      $param = $this->previewDiary($diary_title, $diary_body);
      $param['submit'] = 'confirm';
      
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "addDiary param\n");
	foreach($param as $tmp){
	  fwrite($ftmp, $tmp);
	  fwrite($ftmp, "\n");
	}
	fclose($ftmp);
      }
      
      $result = $this->submit('add_diary.pl', $param);
      
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."submit.html", "wb");
	fwrite($ftmp, $result);
	fclose($ftmp);
      }
      
      $diaryId = $this->getLatestDiaryId();
      
      if($latestDiaryId != $diaryId) {
	return $diaryId;
      }
      return false;
    }
    
    function previewDiary($diary_title, $diary_body) {
        if(!$this->loggedin) {
            return false;
        }
        
        $post = array();
        $post['id'] = $this->getUserId();
        $post['diary_title'] = $diary_title;
        $post['diary_body'] = $diary_body;
        $post['submit'] = 'main';
        $this->snoopy->set_submit_multipart();
        $result = $this->submit('add_diary.pl', $post);

        preg_match_all('/<input type=["\']?([^<>\s]*?)["\']? name=["\']?([^<>\s]*?)["\']? value=["\']?(.*?)["\']? \/>/is', $result, $match, PREG_SET_ORDER);
        $part = array();
        foreach($match as $part) {
            if (!in_array($part[2], $this->mixi_diary_formval)) {
                continue;
            }
            $vars[$part[2]] = $part[3];
        }
        return $vars;
    }
    
    function getUserId() {
        if(!$this->loggedin) {
            return false;
        }
        preg_match('/^([0-9]+)_.+?/', $this->snoopy->cookies['BF_SESSION'], $match);

        return intval($match[1]);
    }
    
    function getLatestDiaryId() {
        if(!$this->loggedin) {
            return false;
        }
        $content = $this->fetch('list_diary.pl');
        if(preg_match('/view_diary\.pl\?id=([0-9]+)/', $content, $result)){
            return intval($result[1]);
        }
        return false;
    }
    
    function existsDiary($diaryId) {
        if(!$this->loggedin) {
            return false;
        }
        $content = $this->fetch('view_diary.pl?id='.$diaryId.'&owner_id='.$this->getUserId());
        return strpos($content, 'add_comment.pl?diary_id='.$diaryId) !== false;
    }
    
    function fetch($url) {
        $url = (strpos($url, 'http://') !== false) ? $url : $this->base_url . $url;
        $this->snoopy->fetch($url);
        return $this->snoopy->results;
    }
    
    function modifyDiary($id, $diary_title, $diary_body) {
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "modifyDiary開始\n");
	fclose($ftmp);
      }

        if(!$this->loggedin) {
            return false;
        }

        $content = $this->fetch('edit_diary.pl?id=' . $id);
        preg_match('/post_key" value="(.+?)"/', $content, $match);
        
        $post['post_key'] = $match[1];
        $post['diary_title'] = $diary_title;
        $post['diary_body'] = $diary_body;
        $post['submit'] = 'main';
        $post['form_date'] = 'date';
        $this->snoopy->set_submit_multipart();
        
        $content = $this->submit('edit_diary.pl?id=' . $id, $post, $file);

        preg_match('/post_key" value="(.+?)"/', $content, $match);
        $post['post_key'] = $match[1];
        $post['diary_title'] = $diary_title;
        $post['diary_body'] = $diary_body;
        $post['submit'] = 'confirm';
        $post['packed'] = '';
        $post['news_title'] = '';
        $post['news_url'] = '';
        $post['movie_id'] = '';
        $post['movie_title'] = '';
        $post['movie_url'] = '';
        $this->snoopy->set_submit_multipart();
        $content = $this->submit('edit_diary.pl?id=' . $id, $post, $file);
		return $content;
	}

    
    function isEnabledMixiDiary() {
      if(!$this->loggedin) {
	if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	  $ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	  fwrite($ftmp, "isEnabledMixiDiary\n");
	  fwrite($ftmp, "false 1\n");
	  fclose($ftmp);
	}
	return false;
      }
      $content = $this->fetch('edit_account.pl');
      
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."isEnableMixiDiary.html", "ab");
	fwrite($ftmp, $content);
	fclose($ftmp);
      }

      if(strpos($content, '<option value="1" selected="selected">') !== false) {
	return true;
      }
      if(WP_MIXIPUBLISHER_DEBUGMODE == 1){
	$ftmp = fopen(WP_MIXIPUBLISHER_DEBUGPATH."dump.dat", "ab");
	fwrite($ftmp, "isEnabledMixiDiary\n");
	fwrite($ftmp, "false 2\n");
	fclose($ftmp);
      }
      return false;
    }
}

function mixipublisher_isEnableSelfExecute() {
    if(basename($_SERVER['SCRIPT_NAME']) == basename(__FILE__)
    /*&& $_SERVER['SERVER_ADDR'] == $_SERVER['REMOTE_ADDR'] */
    && $_GET['post_id']) {
        return true;
    }
    return false;
}

// wp_mixipublisherはここから始まる
$wp_mixipublisher =& WpMixiPublisherController::getInstance();
if(mixipublisher_isEnableSelfExecute()) {
    $wp_mixipublisher->publishToMixi($_GET['post_id']);
}else{
    add_action('admin_menu', array(&$wp_mixipublisher, 'addAdminPanel'));
    add_action('dbx_post_sidebar', array(&$wp_mixipublisher, 'getPublishForm'));
    add_action('publish_post', array(&$wp_mixipublisher, 'publishHandler'));
    add_action('save_post', array(&$wp_mixipublisher, 'saveHandler'));
}
?>
